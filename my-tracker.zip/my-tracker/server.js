const express = require('express');
const app = express();
const PORT = process.env.PORT || 3000;

// وێنەیەکێ شفافێ ١x١ پیکسڵ ب شێوەیێ Base64
const transparentPixel = Buffer.from(
    'R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    'base64'
);

app.get('/track.gif', (req, res) => {
    const clientIP = req.headers['x-forwarded-for'] || req.socket.remoteAddress;
    const userAgent = req.headers['user-agent'];
    const timestamp = new Date().toISOString();

    console.log(`[!] سەردانەک هات!`);
    console.log(`- IP Address: ${clientIP}`);
    console.log(`- Dem: ${timestamp}`);
    console.log(`- Browser: ${userAgent}`);
    console.log('-----------------------------------');

    res.writeHead(200, {
        'Content-Type': 'image/gif',
        'Content-Length': transparentPixel.length,
        'Cache-Control': 'no-store, no-cache, must-revalidate, proxy-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'
    });
    res.end(transparentPixel);
});

app.listen(PORT, () => {
    console.log(`سێرڤەر کاردکەت لسەر پۆرتێ ${PORT}`);
});
